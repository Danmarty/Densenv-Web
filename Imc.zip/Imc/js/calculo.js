let botaoCalcular = document.getElementById(botao_click);
function IMC(){
let peso= document.getElementById("peso").value;
let altura = document.getElementById("altura").value;
let resultado = document.getElementById("resultado")
if(altura !=="" && peso !==""){
let imc = (peso / (altura*altura)).toFixed(2);
resultado.textContent = `Seu IMC é ${imc}!`;
}else{
resultado.textContent = "Preencha corretamente os campos!"
}
}
botao_click.addEventListener('click', IMC);